package com.cg.ibs.rm.ui;

public enum TransactionType {
	DEBIT,CREDIT
}
